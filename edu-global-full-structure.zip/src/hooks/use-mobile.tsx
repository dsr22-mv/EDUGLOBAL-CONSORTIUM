// use-mobile.tsx - placeholder content
