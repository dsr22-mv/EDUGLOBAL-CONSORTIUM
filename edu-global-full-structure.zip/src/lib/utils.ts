// utils.ts - placeholder content
