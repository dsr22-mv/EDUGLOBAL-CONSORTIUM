// resizable.tsx - placeholder content
