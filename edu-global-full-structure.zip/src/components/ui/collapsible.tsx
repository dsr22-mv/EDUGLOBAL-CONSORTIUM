// collapsible.tsx - placeholder content
