// sidebar.tsx - placeholder content
