// hover-card.tsx - placeholder content
