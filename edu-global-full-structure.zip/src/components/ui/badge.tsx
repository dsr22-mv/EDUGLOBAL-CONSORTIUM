// badge.tsx - placeholder content
