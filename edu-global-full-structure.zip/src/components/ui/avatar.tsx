// avatar.tsx - placeholder content
