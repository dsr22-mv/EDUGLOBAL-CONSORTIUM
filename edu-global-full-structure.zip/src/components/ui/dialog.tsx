// dialog.tsx - placeholder content
