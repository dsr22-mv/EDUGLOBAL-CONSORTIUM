// textarea.tsx - placeholder content
