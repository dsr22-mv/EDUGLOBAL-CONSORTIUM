// skeleton.tsx - placeholder content
