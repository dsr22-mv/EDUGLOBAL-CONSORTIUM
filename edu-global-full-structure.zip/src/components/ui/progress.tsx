// progress.tsx - placeholder content
