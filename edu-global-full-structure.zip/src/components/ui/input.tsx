// input.tsx - placeholder content
